# GNue Importer — UE plugin for Blender GN effect packs

Turns folders exported by the Blender **GN to UE Exporter** into parametric PCG
graphs, with the Blender parameters exposed on each volume's Details panel.
Ships two small C++ modules (**GNueParams**, **GNuePCG**) plus editor Python;
prebuilt Win64 binaries for UE 5.8 are included — other engine versions rebuild
from `Source/`.
Depends on the **PCG** and **Python Editor Script** plugins (declared in the
.uplugin).

## Install

Copy this `GNueImporter` folder into `<YourProject>/Plugins/` and restart the
editor. The Output Log shows `[GNue] menu registered` and
`[GNue] auto-apply watcher active` when it's live.

## Import an effect

**Drop folder (plug-and-play):** copy a Blender export folder (contains
`effect.gnue.json` + `meshes/`) into `<YourProject>/GNueDrops/`. New drops
import automatically at editor startup, or via **Tools > GNue Importer >
Scan GNueDrops**. Alternatively **Import Effect Folder…** browses anywhere.

Result: `/Game/GNueImport/<Effect>/PCG_<Effect>`. Drop a **PCG Volume** over
some ground in your level and assign that graph. Scatter (grass/rocks) samples
whatever collidable surface is under the volume.

The effect builds relative to its volume, so **move the volume to move the
effect**. Effects that scatter on a shaped mesh in Blender ship that mesh
with the drop (`SM_GNue_Surface`) — the surface rebuilds at the volume with
the instances growing off its faces. Tag any other actor **`GNueSurface`**
and the effect samples that actor's mesh too, wherever it stands. Effects made of explicit geometry (bridges, circles, spirals, walks)
are also *scaled* by the volume, so keep those volumes at **scale 1** for
exactly the size they were in Blender. For scatter effects the volume is the
scatter area instead — scale those to taste.

## Edit parameters (the fun part)

Select the volume > Details > **Graph Parameters** — the effect's Blender
parameters (Bridge_Width, Sag, densities, Seed, …) are all there.

- **Just edit a value.** About a second after it settles, the effect rebuilds
  and regenerates automatically (auto-apply watcher).
- Each edited volume gets its **own graph copy** under
  `/Game/GNueImport/<Effect>/Instances/<VolumeName>/` — volumes diverge freely;
  the base graph keeps the Blender defaults.
- Manual control: **Tools > GNue Importer > Apply Volume Parameters** (applies
  the selected volume now) and **Toggle Auto Apply** (watcher on/off).

## Iterate from Blender

Re-export from Blender into the same drop folder, then **Tools > GNue Importer
> Reimport All Drops**. Graphs rebuild in place (placed volumes keep working)
and every per-volume copy is refreshed with its own saved parameter values.

## Files

- `Source/GNueParams/` — C++ module: exposes PCG graph-parameter declaration
  to scripting (`GNueParamLibrary.DeclareParameters`)
- `Source/GNuePCG/` — C++ module: the **GNue Scale By Attribute** PCG node,
  which multiplies point scale by a per-point attribute. It exists because UE
  5.8's stock `Attribute Maths Op` (and the rest of that family) silently
  produces no output, making proximity/noise scale math impossible with the
  shipped nodes. The importer wires it up automatically.
- `Content/Python/init_unreal.py` — menus, GNueDrops scan, auto-apply watcher
- `Content/Python/gnue_importer.py` — descriptor v2 importer (numeric kernel +
  PCG emission); `gnue_pcg.py`, `gnue_eval.py` — helpers

The Python files are **generated** from the GNtoUEresearch repo by
`tools/sync_ue_plugin.py`; C++ source is canonical in `ue_plugin_src/`.
Edit there, not here.

## Behavior & limits

- Everything lands under `/Game/GNueImport/` — nothing else in your project is
  touched. Reimports rebuild graphs in place (volume references survive).
- Parameter application is settle-then-rebuild (~1s), not per-frame scrubbing.
- Random placement is statistically equivalent to Blender, never identical.
- Failures never guess: refused imports name the offending nodes in the Output
  Log and the export folder's `export_report.txt`.
- Folder picker dialog is Windows-only; the GNueDrops flow works everywhere.
- If the **GNuePCG** module isn't built for your engine version, imports still
  work: proximity scaling falls back to discrete steps instead of a smooth
  fade, and the importer says so in the Output Log.
- Mesh-surface scatter needs the **PCG Geometry Script Interop** engine plugin
  (declared as a dependency, UE enables it automatically). If it's missing,
  those effects fall back to ground scatter and say so in the Output Log.
