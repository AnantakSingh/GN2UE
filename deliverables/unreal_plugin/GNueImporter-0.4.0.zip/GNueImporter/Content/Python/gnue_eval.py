"""Expression evaluator (generated from gnue_exporter/core.py — do not edit;
run tools/sync_ue_plugin.py in the research repo instead)."""

# ------------------------------------------------------------------ evaluator

class NonConstant(Exception):
    pass


def _v(x):
    return x if isinstance(x, list) else [x, x, x]


def evaluate(e, params, env=None):
    """Numerically evaluate an expression tree. env supplies per-point context
    (spline_factor, index, tangent, ...). Raises NonConstant on random leaves
    or attrs missing from env — callers decide how to realize those in UE."""
    env = env or {}
    if e is None:
        raise NonConstant("empty")
    if "const" in e:
        return e["const"]
    if "param" in e:
        if e["param"] not in params:
            raise NonConstant("unknown param " + e["param"])
        return params[e["param"]]
    if "attr" in e:
        if e["attr"] in env:
            return env[e["attr"]]
        raise NonConstant("attr " + e["attr"])
    if "random" in e:
        raise NonConstant("random")
    if "block_output" in e:
        key = "%s.%s" % (e["block_output"]["block"], e["block_output"]["output"])
        if key in env:
            return env[key]
        raise NonConstant("block_output " + key)
    op = e.get("op")
    if op is None:
        raise NonConstant("unrecognized expr %r" % e)
    A = [evaluate(a, params, env) for a in e.get("args", [])]
    f = _EVAL_OPS.get(op)
    if f is None:
        raise NonConstant("op " + op)
    return f(A)


def _mapr(a):
    v, fmin, fmax, tmin, tmax = a
    if fmax == fmin:
        return tmin
    t = (v - fmin) / (fmax - fmin)
    return tmin + t * (tmax - tmin)


_EVAL_OPS = {
    "math.add": lambda a: a[0] + a[1],
    "math.subtract": lambda a: a[0] - a[1],
    "math.multiply": lambda a: a[0] * a[1],
    "math.divide": lambda a: (a[0] / a[1]) if a[1] else 0.0,
    "math.multiply_add": lambda a: a[0] * a[1] + a[2],
    "math.sine": lambda a: __import__("math").sin(a[0]),
    "math.cosine": lambda a: __import__("math").cos(a[0]),
    "math.power": lambda a: a[0] ** a[1],
    "math.sqrt": lambda a: a[0] ** 0.5,
    "math.absolute": lambda a: abs(a[0]),
    "math.minimum": lambda a: min(a[0], a[1]),
    "math.maximum": lambda a: max(a[0], a[1]),
    "math.floor": lambda a: float(int(a[0]) if a[0] >= 0 else -int(-a[0] + 0.999999)),
    "math.floored_modulo": lambda a: a[0] % a[1] if a[1] else 0.0,
    "math.greater_than": lambda a: 1.0 if a[0] > a[1] else 0.0,
    "math.less_than": lambda a: 1.0 if a[0] < a[1] else 0.0,
    "math.modulo": lambda a: __import__("math").fmod(a[0], a[1]) if a[1] else 0.0,
    "clamp": lambda a: max(a[1], min(a[2], a[0])),
    "map_range": _mapr,
    "mix": lambda a: ([a[1][i] + (a[2][i] - a[1][i]) * a[0] for i in range(3)]
                      if isinstance(a[1], list) else a[1] + (a[2] - a[1]) * a[0]),
    "vec3": lambda a: [a[0], a[1], a[2]],
    "vec.x": lambda a: _v(a[0])[0],
    "vec.y": lambda a: _v(a[0])[1],
    "vec.z": lambda a: _v(a[0])[2],
    "vmath.add": lambda a: [_v(a[0])[i] + _v(a[1])[i] for i in range(3)],
    "vmath.subtract": lambda a: [_v(a[0])[i] - _v(a[1])[i] for i in range(3)],
    "vmath.scale": lambda a: [_v(a[0])[i] * a[1] for i in range(3)],
    "vmath.cross_product": lambda a: [
        _v(a[0])[1] * _v(a[1])[2] - _v(a[0])[2] * _v(a[1])[1],
        _v(a[0])[2] * _v(a[1])[0] - _v(a[0])[0] * _v(a[1])[2],
        _v(a[0])[0] * _v(a[1])[1] - _v(a[0])[1] * _v(a[1])[0]],
    "vmath.normalize": lambda a: (lambda v, n: [c / n for c in v] if n else [0, 0, 0])(
        _v(a[0]), sum(c * c for c in _v(a[0])) ** 0.5),
    "vmath.length": lambda a: sum(c * c for c in _v(a[0])) ** 0.5,
    "vmath.dot_product": lambda a: sum(_v(a[0])[i] * _v(a[1])[i] for i in range(3)),
    "cmp.greater_than": lambda a: a[0] > a[1],
    "cmp.less_than": lambda a: a[0] < a[1],
    "cmp.equal": lambda a: abs(a[0] - a[1]) <= (a[2] if len(a) > 2 else 1e-6),
    "bool.and": lambda a: bool(a[0]) and bool(a[1]),
    "bool.or": lambda a: bool(a[0]) or bool(a[1]),
    "bool.not": lambda a: not a[0],
    "switch": lambda a: a[2] if a[0] else a[1],
}
